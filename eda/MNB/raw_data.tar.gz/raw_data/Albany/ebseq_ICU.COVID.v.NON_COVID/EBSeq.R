OutputSize=T;
OutputBoxplot=T;
OutputFullData=T;
PPThreshold=0.95;
UsePool=T;
Sizes = F;
library(EBSeq);
ReadIn=read.delim("g.ec.tsv",stringsAsFactors=F,header=T,sep="\t")
Headers=unlist(read.table("conditions.c.txt",stringsAsFactors=F))
GeneMat=do.call(cbind, ReadIn[-1])
rownames(GeneMat)=ReadIn[[1]]

if(Sizes==F)Sizes=MedianNorm(GeneMat)
names(Sizes)=colnames(GeneMat)

# Print out the normalization factor
if(OutputSize==T)
write.table(Sizes,file="NormalizationFactors.txt",quote=F,col.names=F)

# Plot the box plot
if(OutputBoxplot==T){
        GeneMat.norm=t(t(GeneMat)/Sizes)
        pdf("Boxplot_NormalizedExpression.pdf")
        boxplot(data.frame(GeneMat.norm),log="y",ylab="Normalized Expression",
        ylim=c(1,max(GeneMat.norm)),main="")
        dev.off()
}

# Run EBSeq
if(UsePool==T) EBres=EBTest(Data=GeneMat,Conditions=as.factor(Headers),sizeFactors=Sizes, maxround=5, Pool=T)
if(UsePool==F) EBres=EBTest(Data=GeneMat,Conditions=as.factor(Headers),sizeFactors=Sizes, maxround=5, Pool=F)
PP=GetPP(EBres)
PP.sort=sort(PP,decreasing=T)
EBDE=names(PP)[which(PP>PPThreshold)]
# FC
DataFC=PostFC(EBres)$RealFC
BigMat=cbind(PP.sort, GeneMat[names(PP.sort),],DataFC[names(PP.sort)])
colnames(BigMat)=c("PP",colnames(GeneMat),"FC")
#c("PP",colnames(GeneMat),"FC")
if(length(EBDE)!=0)SmallMat=BigMat[1:length(EBDE),]
if(length(EBDE)==0)SmallMat=NULL

write.table(SmallMat,file="DEGenes.txt",quote=F)
if(OutputFullData==T)write.table(BigMat,file="AllGenes.txt",quote=F)

