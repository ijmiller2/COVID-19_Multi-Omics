Rscript ../Rs/Normer.Rs g.tpm.tab g.tpm.nfs.txt
../scripts/normer.sh g.tpm.nfs.txt g.tpm.tab g.tpm.norm.tab
Rscript ../Rs/Normer.Rs g.ec.tab g.ec.nfs.txt
../scripts/normer.sh g.ec.nfs.txt g.ec.tab g.ec.norm.tab
#
perl -lane < g.tpm.norm.tab '($g,@t)=@F; if (1 == ++$k){print}else{print join("\t", $g, map{sprintf("%.1f", log($_+1)/log(2))} @t)}' > g.l2tpm.norm.tab
perl -lane < g.ec.norm.tab '($g,@t)=@F; if (1 == ++$k){print}else{print join("\t", $g, map{sprintf("%.1f", log($_+1)/log(2))} @t)}' > g.l2ec.norm.tab
perl -lane < g.ec.norm.tab '($g,@t)=@F; if (1 == ++$k){print}else{$s=0; for $t (@t){$s+=$t} $mn=$s/(scalar @t); print join("\t", $g, map{sprintf("%.1f", log(($_+1)/($mn+1))/log(2))} @t)}' > g.l2fr_to_mean.ec.norm.tab
perl -lane < g.ec.norm.tab '($g,@t)=@F; if (1 == ++$k){print}else{($tMin,@ts)=sort{$a <=> $b} @t; $tMax=pop @ts; $tMid = ($tMax - $tMin)/2; print join("\t", $g, map{sprintf("%.1f", log(($_+1)/($tMid+1))/log(2))} @t)}' > g.l2fr_to_mid.ec.norm.tab
#
mkdir ebseq
cd ebseq
ln -s ../g.ec.tab
ln -s ../conditions.c.txt
cp ../../Rs/EBSeq.R .
cp ../../scripts/UpOrDown_M_N.sh .
nohup R --vanilla < EBSeq.R > EBSeq.R.out 2> EBSeq.R.log
./UpOrDown_M_N.sh
cat All.Genes.Normed.tab | perl -lane  '($g, $pp, @f) = (@F); pop @f; pop @f; print join ("\t", $g, @f)' > ecs.norm.tab
cat All.Genes.Normed.tab | perl -lane  '($g, $pp, @f) = (@F); pop @f; pop @f; print join ("\t", $g, map{sprintf("%.1f", (log($_ + 1)/log(2)))} @f)' > l2ecs.norm.tab
#
#../../scripts/fECaTPM_3_3.sh gt 8 1
#../../scripts/fECaTPM_3_3.sh gt 16 1
#../../scripts/fECaTPM_3_3.sh gt 32 1
#../../scripts/fECaTPM_3_3.sh gt 64 1
##../../scripts/filterECandTPM_3_3.sh gt 16 1
##../../scripts/filterECandTPM_3_3.sh gt 32 1
##../../scripts/filterECandTPM_3_3.sh gt 64 1



##cat $1  genes.log2.tpm.norm.tab \
##  | perl -lane 'if (m/^#/){print}else{($g, @f)=@F; if (defined $f[0]){if ($g{$g}){print;}}else{$g{$g}++}}' \
##  > genes.markers.log2.tpm.norm.tab

##cat $1 genes.log2.ec.norm.tab \
##  | perl -lane 'if (m/^#/){print}else{($g, @f)=@F; if (defined $f[0]){if ($g{$g}){print;}}else{$g{$g}++}}' \
##  > genes.markers.log2.ec.norm.tab

