cat conditions.c.txt NormalizationFactors.txt AllGenes.txt \
  | perl -lane \
   'if (! $cnF) {(@cn)=split /\s+/; $kcn=scalar @cn; $cnF=1; print $_;}
    elsif ($knf < $kcn){($s,$nf)=split /\s+/; push @nf, $nf; $knf++;}
    elsif(! $hdrF){s/\s/\t/mgs; print "#symbol\t$_\tL2FC"; $hdrF=1}
    else{($g,$pp,@f)=split /\s+/; pop @f; @ecn=map{$f[$_]/$nf[$_]}(0..($knf-1)); print join("\t", $g, $pp, @ecn);}' \
  | perl -lane \
   'if (! $cnF) {(@cns)=split/\s+/; $i=0; for $cn (@cns){push @{$icns{$cn}}, $i++; $kcn{$cn}++; $kcn++} $cnF=1; @cnName=sort keys %kcn}
    elsif (! $hdrF){print; $hdrF=1}
    else{($g,$pp,@ecn)=@F; $rs=$hs=0; map{$hs+=$ecn[$_]}@{$icns{$cnName[0]}}; map {$rs+=$ecn[$_]}@{$icns{$cnName[1]}};
         $rs/=$kcn{$cnName[1]}; $hs/=$kcn{$cnName[0]}; $fc=($rs+1)/($hs+1); $lfc=log($fc)/log(2);
         print join("\t", $_, $fc, $lfc);
    }
   ' \
  | perl -lane 'if (1 < ++$k){($g,$pp,@f)=@F; $lfc=pop @f;  print join("\t", $g, sprintf("%.3f",$pp), (map{sprintf("%.f", $_)} @f), sprintf("%.1f",$lfc))}' \
  > All.Genes.Normed.tab

rm Down.Genes.Normed.tab
rm Up.Genes.Normed.tab
##No headers?
## They're left out of All.Genes.Normed.tab in the last step of the thing immediately above ...
##head -n 1 All.Genes.Normed.tab > Down.Genes.Normed.tab
perl -lane < All.Genes.Normed.tab \
 'if (1 < ++$k){($g,$pp,@f)=@F; $lfc=pop @f; if($lfc < 0){ print join("\t", $g, $lfc, sprintf("%.3f",$pp), (map{sprintf("%.f", $_)} @f), sprintf("%.1f", $lfc))}}' \
 | sort -k3,3nr -k2,2n \
 | cut -f 1,3- \
 >> Down.Genes.Normed.tab

##No headers?
##head -n 1 All.Genes.Normed.tab > Up.Genes.Normed.tab
perl -lane < All.Genes.Normed.tab \
 'if (1 < ++$k){($g,$pp,@f)=@F; $lfc=pop @f; if($lfc >= 0){ print join("\t", $g, $lfc, sprintf("%.3f",$pp), (map{sprintf("%.f", $_)} @f), sprintf("%.1f", $lfc))}}' \
 | sort -k3,3nr -k2,2nr \
 | cut -f 1,3- \
 >> Up.Genes.Normed.tab

perl -lane < Down.Genes.Normed.tab 'if ($F[1] >= 0.5){print;}' > Down.Genes.pp50.Normed.tab
perl -lane < Up.Genes.Normed.tab 'if ($F[1] >= 0.5){print;}' > Up.Genes.pp50.Normed.tab
cut -f 1 Down.Genes.pp50.Normed.tab > Down.Genes.pp50.txt
cut -f 1 Up.Genes.pp50.Normed.tab > Up.Genes.pp50.txt

perl -lane < Down.Genes.Normed.tab 'if ($F[1] >= 0.95){print;}' > Down.Genes.pp95.Normed.tab
perl -lane < Up.Genes.Normed.tab 'if ($F[1] >= 0.95){print;}' > Up.Genes.pp95.Normed.tab
cut -f 1 Down.Genes.pp95.Normed.tab > Down.Genes.pp95.txt
cut -f 1 Up.Genes.pp95.Normed.tab > Up.Genes.pp95.txt

perl -lane < Down.Genes.Normed.tab 'if ($F[1] >= 0.99){print;}' > Down.Genes.pp99.Normed.tab
perl -lane < Up.Genes.Normed.tab 'if ($F[1] >= 0.99){print;}' > Up.Genes.pp99.Normed.tab
cut -f 1 Down.Genes.pp99.Normed.tab > Down.Genes.pp99.txt
cut -f 1 Up.Genes.pp99.Normed.tab > Up.Genes.pp99.txt

