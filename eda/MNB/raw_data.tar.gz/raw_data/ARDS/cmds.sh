perl -le 'for $i (0..4){push @c, "ARDS"} for $i (0..7){push @c, "ARDS_HSCT"} print join(" ", @c);' > conditions.c.txt
./x.v.y.cmds.sh > x.v.y.cmds.sh.out 2> x.v.y.cmds.sh.log
