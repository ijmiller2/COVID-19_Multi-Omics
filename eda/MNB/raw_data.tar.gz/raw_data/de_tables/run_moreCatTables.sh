./moreCatTables.sh Up PPDE
./moreCatTables.sh Down PPDE
./moreCatTables.sh All PPDE
./moreCatTables.sh All L2FR
./moreCatTables.sh All MaxEC
