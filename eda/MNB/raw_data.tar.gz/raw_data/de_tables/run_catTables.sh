cat ../AHNMJYDMXX/TS_PE_SE_RSEM/collated/tables/DE_A.map.tsv ../Englert/TS_PE_SE_RSEM/collated/tables/DE_E.map.tsv ../A_and_E/TS_PE_SE_RSEM/collated/tables/DE_AE.map.tsv > DE.map.tsv

./catTables.sh Up 50
./catTables.sh Up 95
./catTables.sh Up 99
./catTables.sh Down 50
./catTables.sh Down 95
./catTables.sh Down 99
