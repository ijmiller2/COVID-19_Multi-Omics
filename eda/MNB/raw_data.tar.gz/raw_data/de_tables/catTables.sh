cat \
 ../AHNMJYDMXX/TS_PE_SE_RSEM/collated/tables/$1*pp$2*.tsv \
 ../Englert/TS_PE_SE_RSEM/collated/tables/$1*pp$2*.tsv \
 ../A_and_E/TS_PE_SE_RSEM/collated/tables/$1*pp$2*.tsv \
| perl -nle \
'($g,@f)=split /\t/;
 if (! $k{$g}){$k{$g}=$_; push @g, $g;}
 else{$k{$g}.=join("\t", "",@f);}
 END{for $g (@g){print $k{$g}}}
' \
> $1.Genes.pp$2.flags.tsv

